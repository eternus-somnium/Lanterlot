﻿using UnityEngine;
using System.Collections;

public class CharacterController : MonoBehaviour {


    [HideInInspector]public bool facingRight = true; 
    [HideInInspector]public bool jump = false;
    
    public float maxspeed = 3;
    public float speed = 50f;
    public float jumpPower = 150f;
    public Transform groundCheck;

    

    private bool grounded = false;
    private Rigidbody2D rb2d;
    private Animator anim;

	void Start () {

        rb2d = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponent<Animator>();

	}
	
	
	void Update () {

        grounded = Physics2D.Linecast(transform.position, groundCheck.position, 1 << LayerMask.NameToLayer("Ground"));

        if (Input.GetButtonDown("Jump") && grounded)
        {
            jump = true;
        }

        
        
	
	}


    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
        anim.SetBool("Grounded", grounded);
        anim.SetFloat("Speed", Mathf.Abs(Input.GetAxis("Horizontal")));

        if (h * rb2d.velocity.x < maxspeed)
            rb2d.AddForce(Vector2.right * h * speed);

        if (Mathf.Abs(rb2d.velocity.x) > maxspeed)
            rb2d.velocity = new Vector2(Mathf.Sign(rb2d.velocity.x) * maxspeed, rb2d.velocity.y);

        if (h > 0 && !facingRight)
            Flip();
        else if (h < 0 && facingRight)
            Flip();
    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}
